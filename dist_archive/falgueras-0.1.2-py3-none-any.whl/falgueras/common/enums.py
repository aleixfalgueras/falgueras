from enum import Enum


class Env(Enum):
    DEV = "dev"
    PRE = "pre"
    PROD = "prod"

